
package com.bus.booking.location;


import java.util.List;

import com.bus.booking.location.location;

public interface LocationService {

  
	int register(location location);

    boolean update(location location);

    location getlocation(int id);

    List<location> getAlllocations();

    boolean delete(int id);

}
