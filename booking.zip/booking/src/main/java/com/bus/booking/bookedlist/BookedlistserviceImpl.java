/**
 * Module: User Module
 * Dependencies: Booking Module
 * Aim: To provide the service implementation for user
 * Author: Srijan Singh
 * Date: 07/06/2023
 */
package com.bus.booking.bookedlist;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import java.util.List;


/**
 * Implementation for User Service
 */
@Repository
public abstract class BookedlistserviceImpl implements BookedlistService {   

    /**
     * Autowired UserRepository
     */
    @Autowired
    private BookedlistRepository BookedlistRepository;

    /**
     * Method to register a user
     * @param user
     */
    
   

    /**
     * Method to login a user
     * @param email
     * @param password
     * @return
     */
   

    /**
     * Method to return a user
     * @param user
     * @return
     */
    @Override
    public Bookedlist getBookedlist(int id) {
        return BookedlistRepository.findById(id).orElse(null);        
    }

    /**
     * Method to get all users
     * @return List<User>
     */
    @Override
    public List<Bookedlist> getAlllocations(){
        return BookedlistRepository.findAll();
    }

    /**
     * Method to update a user
     * @param userID
     * @return
     */
    @Override
    public boolean update(Bookedlist BookedlistNew) {
        Bookedlist BookedlistOld = BookedlistRepository.findById(BookedlistNew.getId()).orElse(null);
        if (BookedlistOld != null) {
            BookedlistOld.setId(BookedlistNew.getId());
            BookedlistOld.setRef_no(BookedlistNew.getRef_no());
			BookedlistOld.setName(BookedlistNew.getName());
			BookedlistOld.setQTY(BookedlistNew.getQTY());
			BookedlistOld.setAmount(BookedlistNew.getAmount());
			BookedlistOld.setStatus(BookedlistNew.getStatus());
            return true;
        }
        return false;
    }

    /**
     * Method to delete a user by ID
     * @param userID
     * @return
     */
    @Override
    public boolean delete(int id) {
        Bookedlist bookedlist = BookedlistRepository.findById(id).orElse(null);
        if (bookedlist != null){
            BookedlistRepository.delete(bookedlist);
            return true;
        }
        return false;
    }

}
