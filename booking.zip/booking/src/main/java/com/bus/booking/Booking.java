package com.bus.booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class Booking {

	public static void main(String[] args) {
		SpringApplication.run(Booking.class, args);
		System.out.println("Started...");
	}

}
