package com.bus.booking.bookedlist;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Bookedlist {
	
	    @Id
	    @GeneratedValue
	    @Column(name = "id")
	    private int id;

		
	    private int Ref_no;
	    
	    
	    private String name;
	    
	    
	    private int QTY;
	    
	    
	    private int Amount;
	    
	    
	    private String status;


		public int getId() {
			return id;
		}


		public void setId(int id) {
			this.id = id;
		}


		public int getRef_no() {
			return Ref_no;
		}


		public void setRef_no(int ref_no) {
			Ref_no = ref_no;
		}


		public String getName() {
			return name;
		}


		public void setName(String name) {
			this.name = name;
		}


		public int getQTY() {
			return QTY;
		}


		public void setQTY(int qTY) {
			QTY = qTY;
		}


		public int getAmount() {
			return Amount;
		}


		public void setAmount(int amount) {
			Amount = amount;
		}


		public String getStatus() {
			return status;
		}


		public void setStatus(String status) {
			this.status = status;
		}


		public Bookedlist(int id, int ref_no, String name, int qTY, int amount, String status) {
			super();
			this.id = id;
			Ref_no = ref_no;
			this.name = name;
			QTY = qTY;
			Amount = amount;
			this.status = status;
		}


		public Bookedlist() {
			super();
			
	  }
}
