import { BusSchedule } from './bus-schedule';

describe('BusSchedule', () => {
  it('should create an instance', () => {
    expect(new BusSchedule()).toBeTruthy();
  });
});
