import { LocationComponent } from './location/location.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegistrationComponent } from './registration/registration.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { BusComponent } from './bus/bus.component';
import { ScheduleComponent } from './schedule/schedule.component';
import { ManageUserComponent } from './manage-user/manage-user.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { FindScheduleComponent } from './find-schedule/find-schedule.component';
import { BookingComponent } from './booking/booking.component';

const routes: Routes = [
  {path: '', component:UserLoginComponent},
  {path: 'register', component:RegistrationComponent},
  {path: 'login', component:UserLoginComponent},
  {path: 'adminhome', component:AdminHomeComponent},
  {path: 'adminhome/buses', component:BusComponent},
  {path: 'adminhome/locations', component:LocationComponent},
  {path: 'adminhome/schedules', component:ScheduleComponent},
  {path: 'adminhome/manage', component:ManageUserComponent},
  {path: 'userhome', component:UserHomeComponent},
  {path: 'find', component:FindScheduleComponent},
  {path: 'adminhome/booking', component:BookingComponent}
  


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
