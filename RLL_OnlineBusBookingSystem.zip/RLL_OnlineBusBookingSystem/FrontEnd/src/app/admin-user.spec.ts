import { AdminUser } from './admin-user';

describe('AdminUser', () => {
  it('should create an instance', () => {
    expect(new AdminUser("", "")).toBeTruthy();
  });
});
