import { BusLocation } from './buslocation';

describe('BusLocation', () => {
  it('should create an instance', () => {
    expect(new BusLocation()).toBeTruthy();
  });
});
