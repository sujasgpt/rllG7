package com.bus.booking.locationlist;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Locationlist {
    @Id
    @GeneratedValue
    @Column(name = "id")
    private int id;

    private String terminal;
    
    private String city;
    
    private String province;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTerminal() {
		return terminal;
	}

	public void setTerminal(String terminal) {
		this.terminal = terminal;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public Locationlist(int id, String terminal, String city, String province) {
		super();
		this.id = id;
		this.terminal = terminal;
		this.city = city;
		this.province = province;
	}

	public Locationlist() {
		super();
	}

	
   

    
}
