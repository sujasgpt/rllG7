export class Booking {
    
    public id : number = 0;
    public refnumber : string = "";
    public name : string = "";
    public quantity : number = 0;
    public amount : number = 0;
    public status : string = "";
}
