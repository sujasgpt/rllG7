
package com.bus.booking.locationlist;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LocationlistRepository extends JpaRepository<Locationlist, Integer> {
 
}
