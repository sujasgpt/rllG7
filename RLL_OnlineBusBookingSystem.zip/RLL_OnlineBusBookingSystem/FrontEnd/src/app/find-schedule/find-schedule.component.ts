import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LocationService } from '../location.service';
import { ScheduleService } from '../schedule.service';
import { BusLocation } from '../buslocation';
import { BusSchedule } from '../bus-schedule';
import { BookingService } from '../booking.service';
import { Booking } from '../booking';
import { Location } from '@angular/common';


@Component({
  selector: 'app-find-schedule',
  templateUrl: './find-schedule.component.html',
  styleUrls: ['./find-schedule.component.css']
})
export class FindScheduleComponent implements OnInit {

visibleDiv: number = 1;
 sch:BusSchedule = new BusSchedule();
 schinfo:BusSchedule[] = [];
 locinfo:BusLocation[] = [];
 oldsch:BusSchedule = new BusSchedule();
 schid : number = 0;
 msg:string = "";
 newbooking: Booking = new Booking();
  username:any;

  constructor(private service:ScheduleService, private router:Router, private locationservice:LocationService, private bookingservice:BookingService,
    private location: Location) { }

  ngOnInit(): void {
    this.service.GetAllSchedules().subscribe(data=>{
      this.schinfo = data;
    })
    this.locationservice.GetAllLocations().subscribe(data=>{
      this.locinfo = data;
    })
  }

  showDiv(divNumber: number) {
    this.visibleDiv = divNumber;
  }

  FindSchedule()
  {
    console.log(this.sch.date);
    console.log(this.sch.destination);
    console.log(this.sch.startingpoint);
    this.service.FindSchedule(this.sch.startingpoint, this.sch.destination, this.sch.date).subscribe(data=>{
      this.oldsch= data;
      console.log(this.oldsch.bus);
      if(this.oldsch.bus === null){
        this.msg = "No Schedule Found For Selected Values";
      }
      else{
        this.msg="";
        this.showDiv(2);
      }
    })
  }

  register(){
    if (this.newbooking.name === null || this.newbooking.name === ""){
   console.log(localStorage.getItem('userName'));
    this.username = localStorage.getItem('userName');
    this.newbooking.name = this.username;
    }
    const randomNumber = Math.floor(Math.random() * (2000 - 1000 + 1)) + 1000;
    this.newbooking.refnumber = "BO" + randomNumber;
    this.newbooking.status = "Unpaid";
    this.bookingservice.NewBooking(this.newbooking).subscribe(data=>{
      console.log(data);
      alert("Ticket Booked Awaiting Payment")
      this.refreshPage();
    });
  }

ShowAmount()
{
  //console.log(this.newbooking.quantity);
  if (this.newbooking.quantity !== undefined) {
    if(this.newbooking.quantity > this.oldsch.availability) {
      alert("This Quantity is not Available")
    }
    this.newbooking.amount = this.newbooking.quantity * this.oldsch.price;
  }
  //console.log(this.sch.price);
  //console.log(this.newbooking.amount);
}

refreshPage() {
  this.location.go(this.location.path());
  window.location.reload();
}

}
