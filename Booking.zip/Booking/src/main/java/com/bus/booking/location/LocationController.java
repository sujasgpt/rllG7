
package com.bus.booking.location;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bus.booking.user.User;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class LocationController {

    @Autowired
    private LocationService LocationService;

    @PostMapping(value="/schedule/registration", consumes="application/json")
    public int registerLocation(@RequestBody location location){
        return LocationService.register(location);
    }

    @GetMapping(value="/schedule/get/{schID}", produces="application/json")
    public location getLocationByBusNo(@PathVariable int schID) {
        return LocationService.getlocation(schID);
    }
 
    @GetMapping(value="/schedule/listAll", produces="application/json")
    public List<location> getAllLocation() {
        return LocationService.getAlllocations();
    }

    @PutMapping(value="/schedule/update", consumes="application/json")
    public boolean updateLocation(@RequestBody location location) {
        return LocationService.update(location);
    }

    @DeleteMapping(value="/schedule/delete/{userID}")
    public boolean deleteLocation(@PathVariable int BusNo) {
        return LocationService.delete(BusNo);
    }    
}
