export class Bus {
    public id : number = 0;
    public number : string = "";
    public name : string = "";
}
