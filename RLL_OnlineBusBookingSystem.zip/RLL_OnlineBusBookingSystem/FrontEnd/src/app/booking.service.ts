import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Booking } from './booking';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  constructor(private httpClient:HttpClient) { }

  private RegUrl = "http://localhost:9001/booking/registration";
  private AllUrl = "http://localhost:9001/booking/listAll";
  private SearchUrl = "http://localhost:9001/booking/get";
  private UpdateUrl = "http://localhost:9001/booking/update";
  private DeleteUrl = "http://localhost:9001/booking/delete";

GetAllBookings()
{
  return this.httpClient.get<Booking[]>(`${this.AllUrl}`);
}

NewBooking(booking:Booking)
{
  return this.httpClient.post(`${this.RegUrl}`, booking);
}

SearchBooking(id:number)
{
  return this.httpClient.get<Booking>(`${this.SearchUrl}/${id}`);
}

DeleteBooking(id:number)
{
  return this.httpClient.delete(`${this.DeleteUrl}/${id}`);
}

UpdateBooking(id:number, booking:Booking)
{
  return this.httpClient.put(`${this.UpdateUrl}`, booking);
}

}
