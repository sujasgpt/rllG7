import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Bus } from './bus';


@Injectable({
  providedIn: 'root'
})
export class BusService {

  constructor(private httpClient:HttpClient) { }

  private RegUrl = "http://localhost:9001/bus/registration";
  private AllUrl = "http://localhost:9001/bus/listAll";
  private SearchUrl = "http://localhost:9001/bus/get";
  private UpdateUrl = "http://localhost:9001/bus/update";
  private DeleteUrl = "http://localhost:9001/bus/delete";

GetAllBuses()
{
  return this.httpClient.get<Bus[]>(`${this.AllUrl}`);
}

NewBus(bus:Bus)
{
  return this.httpClient.post(`${this.RegUrl}`, bus);
}

SearchBus(id:number)
{
  return this.httpClient.get<Bus>(`${this.SearchUrl}/${id}`);
}

DeleteBus(id:number)
{
  return this.httpClient.delete(`${this.DeleteUrl}/${id}`);
}

UpdateBus(id:number, bus:Bus)
{
  return this.httpClient.put(`${this.UpdateUrl}`, bus);
}

}
