export class BusLocation {
    public id : number = 0;
    public terminal : string = "";
    public city : string = "";
    public state : string = "";
}
