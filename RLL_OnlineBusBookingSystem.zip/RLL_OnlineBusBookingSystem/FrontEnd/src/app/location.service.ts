import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
//import { Location } from '@angular/common';
import { BusLocation } from './buslocation';

@Injectable({
  providedIn: 'root'
})
export class LocationService {

  constructor(private httpClient:HttpClient) { }

  private RegUrl = "http://localhost:9001/location/registration";
  private AllUrl = "http://localhost:9001/location/listAll";
  private SearchUrl = "http://localhost:9001/location/get";
  private UpdateUrl = "http://localhost:9001/location/update";
  private DeleteUrl = "http://localhost:9001/location/delete";

GetAllLocations()
{
  return this.httpClient.get<BusLocation[]>(`${this.AllUrl}`);
}

NewLocation(location:BusLocation)
{
  return this.httpClient.post(`${this.RegUrl}`, location);
}

SearchLocation(id:number)
{
  return this.httpClient.get<BusLocation>(`${this.SearchUrl}/${id}`);
}

DeleteLocation(id:number)
{
  return this.httpClient.delete(`${this.DeleteUrl}/${id}`);
}

UpdateLocation(id:number, location:BusLocation)
{
  return this.httpClient.put(`${this.UpdateUrl}`, location);
}

}
