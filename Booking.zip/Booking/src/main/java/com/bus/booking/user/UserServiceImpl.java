package com.bus.booking.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import java.util.List;

@Repository
public class UserServiceImpl implements UserService {   

    @Autowired
    private UserRepository userRepository;

    @Override
    public int register(User user) {
        userRepository.save(user);
        return user.getId();
    }


    @Override
    public User login(String email, String password) {
        if (userRepository.findByEmailAndPassword(email, password) != null) {
            return userRepository.findByEmail(email);
        }
        return new User();
    }


    @Override
    public User getUser(int id) {
        return userRepository.findById(id).orElse(null);        
    }

    @Override
    public List<User> getAllUsers(){
        return userRepository.findAll();
    }

    @Override
    public boolean update(User userNew) {
        User userOld = userRepository.findById(userNew.getId()).orElse(null);
        if (userOld != null) {
            userOld.setName(userNew.getName());
            userOld.setEmail(userNew.getEmail());
            userOld.setPassword(userNew.getPassword());
            userRepository.save(userOld);
            return true;
        }
        return false;
    }

    @Override
    public boolean delete(int id) {
        User user = userRepository.findById(id).orElse(null);
        if (user != null) {
            userRepository.delete(user);
            return true;
        }
        return false;
    }
}
