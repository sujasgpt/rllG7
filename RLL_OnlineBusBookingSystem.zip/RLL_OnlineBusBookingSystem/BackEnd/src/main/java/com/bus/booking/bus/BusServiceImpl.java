package com.bus.booking.bus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import java.util.List;


/**
 * Implementation for Bus Service
 */
@Repository
public class BusServiceImpl implements BusService {   

    /**
     * Autowired busRepository
     */
    @Autowired
    private BusRepository busRepository;

    /**
     * Method to register a bus
     * @param bus
     */
	@Override
	public int register(Bus bus) {
		busRepository.save(bus);
        return bus.getId();
	}

	/**
     * Method to update a bus
     * @param bus
     * @return 
     */
	@Override
	public boolean update(Bus busNew) {
		
		 Bus busOld = busRepository.findById(busNew.getId()).orElse(null);
	        if (busOld != null) {
	            busOld.setName(busNew.getName());
	            busOld.setNumber(busNew.getNumber());
	            busRepository.save(busOld);
	            return true;
	        }
	        return false;
		
	}

	 /**
     * Method to get a bus by ID
     * @param busID
     * @return Bus
     */
	@Override
	public Bus getBus(int busID) {
		return busRepository.findById(busID).orElse(null);
	}

	/**
     * Method to get all buss
     * @return List<Bus>
     */
	@Override
	public List<Bus> getAllBuses() {
		return busRepository.findAll();
	}
	
	/**
     * Method to delete a bus
     * @param busID
     * @return
     */
	@Override
    public boolean delete(int busID) {
        Bus bus = busRepository.findById(busID).orElse(null);
        if (bus != null) {
            busRepository.delete(bus);
            return true;
        }
        return false;
    }

	/**
     * Method to get a bus by Number
     * @param Number
     * @return Bus
     */
	@Override
	public Bus findByNumber(String number) {
		if (busRepository.findByNumber(number) != null) {
            return busRepository.findByNumber(number);
        }
        return new Bus(); 
	} 

	/**
     * Method to get a bus by Name
     * @param Name
     * @return Bus
     */
	@Override
	public Bus findByName(String name) {
		if (busRepository.findByName(name) != null) {
            return busRepository.findByName(name);
        }
        return new Bus();
	}
	
}
