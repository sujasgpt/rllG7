package com.bus.booking.booking;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Booking {
    @Id
    @GeneratedValue
    @Column(name = "booking_id")
    private int id;

    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String refnumber;
    
    @Column(length = 20)
    private String name;
    
    @Column
    private int quantity;
    
    @Column
    private int amount;
    
    @Column
    private String status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRefnumber() {
		return refnumber;
	}

	public void setRefnumber(String refnumber) {
		this.refnumber = refnumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Booking(int id, String refnumber, String name, int quantity, int amount, String status) {
		super();
		this.id = id;
		this.refnumber = refnumber;
		this.name = name;
		this.quantity = quantity;
		this.amount = amount;
		this.status = status;
	}

	public Booking() {
		super();
	}
    
}
