package com.bus.booking.locationlist;


import java.util.List;

import com.bus.booking.user.User;

public interface LocationlistService {

	 int register(Locationlist locationlist);

    boolean update(Locationlist locationlist);

    Locationlist getlocation(int id);

    List<Locationlist> getAlllocations();

    boolean delete(int id);

}
