import { LocationService } from './../location.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BusLocation} from '../buslocation';
import { Location } from '@angular/common';


@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.css']
})
export class LocationComponent implements OnInit {

  visibleDiv: number = 1;
  location:BusLocation = new BusLocation();
  locationinfo:BusLocation[] = [];
  oldlocation:BusLocation = new BusLocation();
  locationid : number = 0;

  constructor(private service:LocationService, private router:Router, private angularlocation:Location) { }
  
  
  ngOnInit(): void {
    this.service.GetAllLocations().subscribe(data=>{
      this.locationinfo = data;
    })
    
  }

  register(){
 
    this.service.NewLocation(this.location).subscribe(data=>{
      console.log(data);
      //alert("New Employee is Added Successfully...");
      //this.router.navigate(['login']);
      this.refreshPage();
    });
  }

  showDiv(divNumber: number) {
    this.visibleDiv = divNumber;
  }

  refreshPage() {
    this.angularlocation.go(this.angularlocation.path());
    window.location.reload();
  }

  ShowUpdateLocation(id:number)
  {
    this.locationid = id;
    this.service.SearchLocation(this.locationid).subscribe(data=>{
      this.oldlocation= data;
      console.log(this.locationid);
    })
  }

  UpdateLocation(){
    this.service.UpdateLocation(this.locationid, this.oldlocation).subscribe(data=>{
      //this.router.navigate(['/adminhome']);
      this.refreshPage();
    })
  }

  DeleteLocation(id:number)
    {
      if (window.confirm('Are you sure you want to delete this location?'))
      this.service.DeleteLocation(id).subscribe(data=>{
        this.refreshPage();
      });
    }
  


}
