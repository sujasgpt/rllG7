import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { BusSchedule } from './bus-schedule';

@Injectable({
  providedIn: 'root'
})
export class ScheduleService {

  constructor(private httpClient:HttpClient) { }

  private RegUrl = "http://localhost:9001/schedule/registration";
  private AllUrl = "http://localhost:9001/schedule/listAll";
  private SearchUrl = "http://localhost:9001/schedule/get";
  private UpdateUrl = "http://localhost:9001/schedule/update";
  private DeleteUrl = "http://localhost:9001/schedule/delete";

GetAllSchedules()
{
  return this.httpClient.get<BusSchedule[]>(`${this.AllUrl}`);
}

NewSchedule(sch:BusSchedule)
{
  return this.httpClient.post(`${this.RegUrl}`, sch);
}

SearchSchedule(id:number)
{
  return this.httpClient.get<BusSchedule>(`${this.SearchUrl}/${id}`);
}

DeleteSchedule(id:number)
{
  return this.httpClient.delete(`${this.DeleteUrl}/${id}`);
}

UpdateSchedule(id:number, sch:BusSchedule)
{
  return this.httpClient.put(`${this.UpdateUrl}`, sch);
}

FindSchedule(from:string, to:string, date:string)
{
  const encodeFrom = encodeURIComponent(from);
    const encodeTo = encodeURIComponent(to);
    const encodeDate = encodeURIComponent(date);
  return this.httpClient.get<BusSchedule>(`${this.SearchUrl}/${encodeFrom}/${encodeTo}/${encodeDate}`);
}

}
