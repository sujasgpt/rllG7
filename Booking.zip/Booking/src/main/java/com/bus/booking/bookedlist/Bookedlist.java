package com.bus.booking.bookedlist;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Bookedlist {
	
	    @Id
	    @GeneratedValue
	    @Column(name = "id")
	    private int id;

		
	    private int ref_no;
	    
	    
	    private String name;
	    
	    
	    private int qty;
	    
	    private int amount;
	    
	    
	    private String status;


		

		public int getId() {
			return id;
		}


		public void setId(int id) {
			this.id = id;
		}


		public int getRef_no() {
			return ref_no;
		}


		public void setRef_no(int ref_no) {
			this.ref_no = ref_no;
		}


		public String getName() {
			return name;
		}


		public void setName(String name) {
			this.name = name;
		}


		public int getQty() {
			return qty;
		}


		public void setQty(int qty) {
			this.qty = qty;
		}


		public int getAmount() {
			return amount;
		}


		public void setAmount(int amount) {
			this.amount = amount;
		}


		public String getStatus() {
			return status;
		}


		public void setStatus(String status) {
			this.status = status;
		}


		


		public Bookedlist(int id, int ref_no, String name, int qty, int amount, String status) {
			super();
			this.id = id;
			this.ref_no = ref_no;
			this.name = name;
			this.qty = qty;
			this.amount = amount;
			this.status = status;
		}


		public Bookedlist() {
			super();
			
	  }
}
