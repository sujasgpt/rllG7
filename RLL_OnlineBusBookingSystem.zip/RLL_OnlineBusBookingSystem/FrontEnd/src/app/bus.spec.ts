import { Bus } from './bus';

describe('Bus', () => {
  it('should create an instance', () => {
    expect(new Bus()).toBeTruthy();
  });
});
