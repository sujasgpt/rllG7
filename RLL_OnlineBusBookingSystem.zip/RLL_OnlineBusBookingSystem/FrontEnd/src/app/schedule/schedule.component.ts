import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { BusSchedule } from '../bus-schedule';
import { ScheduleService } from '../schedule.service';
import { LocationService } from '../location.service';
import { BusService } from '../bus.service';
import { Bus } from '../bus';
import { BusLocation } from '../buslocation';


@Component({
  selector: 'app-schedule',
  templateUrl: './schedule.component.html',
  styleUrls: ['./schedule.component.css']
})
export class ScheduleComponent implements OnInit {

 visibleDiv: number = 1;
 sch:BusSchedule = new BusSchedule();
 schinfo:BusSchedule[] = [];
 locinfo:BusLocation[] = [];
 businfo:Bus[] = [];
 oldsch:BusSchedule = new BusSchedule();
 schid : number = 0;
  constructor(private service:ScheduleService, private router:Router, private location: Location,
    private busservice:BusService, private locationservice:LocationService) { }
  
  
  ngOnInit(): void {
    this.service.GetAllSchedules().subscribe(data=>{
      this.schinfo = data;
    })
    this.busservice.GetAllBuses().subscribe(data=>{
      this.businfo = data;
    })
    this.locationservice.GetAllLocations().subscribe(data=>{
      this.locinfo = data;
    })
  }

  register(){
 
    this.service.NewSchedule(this.sch).subscribe(data=>{
      console.log(data);
      this.refreshPage();
    });
  }

  showDiv(divNumber: number) {
    this.visibleDiv = divNumber;
  }

  refreshPage() {
    this.location.go(this.location.path());
    window.location.reload();
  }

  ShowUpdateSchedule(id:number)
  {
    this.schid = id;
    this.service.SearchSchedule(this.schid).subscribe(data=>{
      this.oldsch= data;
      console.log(this.schid);
    })
  }

  UpdateSchedule(){
    this.service.UpdateSchedule(this.schid, this.oldsch).subscribe(data=>{
      this.refreshPage();
    })
  }

  DeleteSchedule(id:number)
    {
      if (window.confirm('Are you sure you want to delete this Schedule?'))
      this.service.DeleteSchedule(id).subscribe(data=>{
        this.refreshPage();
      });
    }

}
