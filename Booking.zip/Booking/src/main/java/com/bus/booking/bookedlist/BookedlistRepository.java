package com.bus.booking.bookedlist;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BookedlistRepository extends JpaRepository<Bookedlist, Integer> {

}
