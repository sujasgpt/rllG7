
package com.bus.booking.bookedlist;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bus.booking.user.User;

import java.util.List;


@Service
public class BookedlistserviceImpl implements BookedlistService {   

    @Autowired
    private BookedlistRepository BookedlistRepository;

	@Override
	public int register(Bookedlist bookedlist) {
		BookedlistRepository.save(bookedlist);
        return bookedlist.getId();
	}

	@Override
	public boolean update(Bookedlist bookedlistNew) {
		Bookedlist listOld = BookedlistRepository.findById(bookedlistNew.getId()).orElse(null);
	        if (listOld != null) {
	            listOld.setRef_no(bookedlistNew.getRef_no());
	            listOld.setName(bookedlistNew.getName());
	            listOld.setQty(bookedlistNew.getQty());
	            listOld.setAmount(bookedlistNew.getAmount());
	            listOld.setStatus(bookedlistNew.getStatus());
	            BookedlistRepository.save(listOld);
	            return true;
	        }
	        return false;
		
	}

	@Override
	public Bookedlist getbookedlist(int id) {
		 return BookedlistRepository.findById(id).orElse(null);     
	}

	@Override
	public List<Bookedlist> getAllbookedlist() {
		return BookedlistRepository.findAll();
	}

	@Override
	public boolean delete(int id) {
		Bookedlist bookedlist = BookedlistRepository.findById(id).orElse(null);
        if (bookedlist != null) {
        	BookedlistRepository.delete(bookedlist);
            return true;
        }
        return false;
	}

	

}
