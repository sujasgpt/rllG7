package com.bus.booking.location;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class location {
	
	    @Id
	    @GeneratedValue
	    @Column(name = "sch_id")
	    private int id;

		
	    
	    @Column
	    private String busname;
	    
	    @Column
	    private String fromlocation;
	    
	    @Column
	    private String tolocation;
	    
	    @Column
	    private String departuredate;
	    
	    @Column
	    private String departuretime;
	    
	    @Column
	    private String etadate;
	    
	    @Column
	    private String etatime;
	    
	    @Column
	    private int avaliability;
	    
	    @Column
	    private int price;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getBusname() {
			return busname;
		}

		public void setBusname(String busname) {
			this.busname = busname;
		}

		public String getFromlocation() {
			return fromlocation;
		}

		public void setFromlocation(String fromlocation) {
			this.fromlocation = fromlocation;
		}

		public String getTolocation() {
			return tolocation;
		}

		public void setTolocation(String tolocation) {
			this.tolocation = tolocation;
		}

		public String getDeparturedate() {
			return departuredate;
		}

		public void setDeparturedate(String departuredate) {
			this.departuredate = departuredate;
		}

		public String getDeparturetime() {
			return departuretime;
		}

		public void setDeparturetime(String departuretime) {
			this.departuretime = departuretime;
		}

		public String getEtadate() {
			return etadate;
		}

		public void setEtadate(String etadate) {
			this.etadate = etadate;
		}

		public String getEtatime() {
			return etatime;
		}

		public void setEtatime(String etatime) {
			this.etatime = etatime;
		}

		public int getAvaliability() {
			return avaliability;
		}

		public void setAvaliability(int avaliability) {
			this.avaliability = avaliability;
		}

		public int getPrice() {
			return price;
		}

		public void setPrice(int price) {
			this.price = price;
		}

		public location(int id, String busname, String fromlocation, String tolocation, String departuredate,
				String departuretime, String etadate, String etatime, int avaliability, int price) {
			super();
			this.id = id;
			this.busname = busname;
			this.fromlocation = fromlocation;
			this.tolocation = tolocation;
			this.departuredate = departuredate;
			this.departuretime = departuretime;
			this.etadate = etadate;
			this.etatime = etatime;
			this.avaliability = avaliability;
			this.price = price;
		}

		public location() {
			super();
		}

		
	    
	    
	    

		
	  
	   

		

	    

	    
	}

