package com.bus.booking.schedule;


import java.util.List;

public interface ScheduleService {

    int register(Schedule sch);

    boolean update(Schedule sch);

    Schedule getSchedule(int schID);

    List<Schedule> getAllSchedules();

    boolean delete(int schID);
    
    Schedule findByStartingpointAndDestinationAndDate(String startingpoint, String destination, String date);
    
}
