
package com.bus.booking.locationlist;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bus.booking.user.User;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class LocationlistController {
 
    @Autowired
    private LocationlistService LocationlistService;

    @PostMapping(value="/locationlist/registration", consumes="application/json")
    public int registerlocationlist(@RequestBody Locationlist locationlist){
        return LocationlistService.register(locationlist);
    }

    @GetMapping(value="/locationlist/get/{id}", produces="application/json")
    public Locationlist getLocationlistByID(@PathVariable int id) {
        return LocationlistService.getlocation(id);
    }

    @GetMapping(value="/locationlist/listAll", produces="application/json")
    public List<Locationlist> getAlllocations() {
        return LocationlistService.getAlllocations();
    }

    @PutMapping(value="/Locationlist/update", consumes="application/json")
    public boolean updateLocationlist(@RequestBody Locationlist locationlist) {
        return LocationlistService.update(locationlist);
    }

    @DeleteMapping(value="/locationlist/delete/{id}")
    public boolean deleteUser(@PathVariable int id) {
        return LocationlistService.delete(id);
    }    
}
