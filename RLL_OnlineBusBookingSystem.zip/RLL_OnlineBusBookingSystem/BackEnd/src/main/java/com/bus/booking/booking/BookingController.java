package com.bus.booking.booking;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class BookingController {
    
    @Autowired
    private BookingService bookingService;

    
    @PostMapping(value="/booking/registration", consumes="application/json")
    public int registerBooking(@RequestBody Booking booking){
        return bookingService.register(booking);
    }

    
    @GetMapping(value="/booking/get/{bookingID}", produces="application/json")
    public Booking getBookingByID(@PathVariable int bookingID) {
        return bookingService.getBooking(bookingID);
    }

    
    @GetMapping(value="/booking/listAll", produces="application/json")
    public List<Booking> getAllBookings() {
        return bookingService.getAllBookings();
    }

    @PutMapping(value="/booking/update", consumes="application/json")
    public boolean updateBooking(@RequestBody Booking booking) {
        return bookingService.update(booking);
    }

    @DeleteMapping(value="/booking/delete/{bookingID}")
    public boolean deleteBooking(@PathVariable int bookingID) {
        return bookingService.delete(bookingID);
    }    
    
    @GetMapping(value="/booking/get/name/{name}", produces="application/json")
    public Booking findByName(@PathVariable String name) {
        return bookingService.findByName(name);
    }
}
