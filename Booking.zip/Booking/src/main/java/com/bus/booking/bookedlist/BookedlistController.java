
package com.bus.booking.bookedlist;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class BookedlistController {
  
    @Autowired
    private BookedlistService BookedlistService;
    
    @PostMapping(value="/bookedlist/registration", consumes="application/json")
    public int registerBookedlist(@RequestBody Bookedlist booked){
        return BookedlistService.register(booked);
    }
    

    @GetMapping(value="/bookedlist/get/{id}", produces="application/json")
    public Bookedlist getbookedlistByID(@PathVariable int id) {
        return BookedlistService.getbookedlist(id);
    }
  
    @GetMapping(value="/bookedlist/listAll", produces="application/json")
    public List<Bookedlist> getAllbooked() {
        return BookedlistService.getAllbookedlist();
    }

    @PutMapping(value="/bookedlist/update", consumes="application/json")
    public boolean updateBookedlist(@RequestBody Bookedlist bookedlist) {
        return BookedlistService.update(bookedlist);
    }

    @DeleteMapping(value="/bookedlist/delete/{id}")
    public boolean deleteBookedlistr(@PathVariable int id) {
        return BookedlistService.delete(id);
    }    
}
