/**
 * Module: User Module
 * Dependencies: Booking Module
 * Aim: To provide the service for user
 * Author: Srijan Singh
 * Date: 07/06/2023
 */
package com.bus.booking.bookedlist;


import java.util.List;

public interface BookedlistService {

	int register (Bookedlist bookedlist);
	
	
	boolean update(Bookedlist bookedlist);


    Bookedlist getbookedlist(int id);

  
    List<Bookedlist> getAllbookedlist();


    boolean delete(int id);

}
