import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Bus } from '../bus';
import { BusService } from '../bus.service';
import { Location } from '@angular/common';



@Component({
  selector: 'app-bus',
  templateUrl: './bus.component.html',
  styleUrls: ['./bus.component.css']
})
export class BusComponent implements OnInit {

  visibleDiv: number = 1;
  bus:Bus = new Bus();
  businfo:Bus[] = [];
  oldbus:Bus = new Bus();
  busid : number = 0;
  constructor(private service:BusService, private router:Router, private location: Location) { }
  
  
  ngOnInit(): void {
    this.service.GetAllBuses().subscribe(data=>{
      this.businfo = data;
    })
    
  }

  register(){
 
    this.service.NewBus(this.bus).subscribe(data=>{
      console.log(data);
      //alert("New Employee is Added Successfully...");
      //this.router.navigate(['login']);
      this.refreshPage();
    });
  }

  showDiv(divNumber: number) {
    this.visibleDiv = divNumber;
  }

  refreshPage() {
    this.location.go(this.location.path());
    window.location.reload();
  }

  ShowUpdateBus(id:number)
  {
    this.busid = id;
    this.service.SearchBus(this.busid).subscribe(data=>{
      this.oldbus= data;
      console.log(this.busid);
    })
  }

  UpdateBus(){
    this.service.UpdateBus(this.busid, this.oldbus).subscribe(data=>{
      //this.router.navigate(['/adminhome']);
      this.refreshPage();
    })
  }

  DeleteBus(id:number)
    {
      if (window.confirm('Are you sure you want to delete this bus?'))
      this.service.DeleteBus(id).subscribe(data=>{
        this.refreshPage();
      });
    }
  

}
