import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FindScheduleComponent } from './find-schedule.component';

describe('FindScheduleComponent', () => {
  let component: FindScheduleComponent;
  let fixture: ComponentFixture<FindScheduleComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FindScheduleComponent]
    });
    fixture = TestBed.createComponent(FindScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
