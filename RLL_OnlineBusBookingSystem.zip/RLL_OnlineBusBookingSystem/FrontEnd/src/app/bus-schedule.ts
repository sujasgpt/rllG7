export class BusSchedule {
    public id : number = 0;
    public date : string = "";
    public bus : string = "";
    public startingpoint : string = "";
    public destination : string = "";
    public time : string = "";
    public etadate : string = "";
    public etatime : string = "";
    public availability : number = 0;
    public price : number = 0;
}
