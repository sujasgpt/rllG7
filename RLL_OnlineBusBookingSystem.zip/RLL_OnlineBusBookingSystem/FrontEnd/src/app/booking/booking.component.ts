import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { BookingService } from '../booking.service';
import { Booking } from '../booking';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {

  visibleDiv: number = 1;
  booking:Booking = new Booking();
  bookinginfo:Booking[] = [];
  oldbooking:Booking = new Booking();
  bookingid : number = 0;
  constructor(private service:BookingService, private router:Router, private location: Location) { }
  
  
  ngOnInit(): void {
    this.service.GetAllBookings().subscribe(data=>{
      this.bookinginfo = data;
    })
    
  }

  showDiv(divNumber: number) {
    this.visibleDiv = divNumber;
  }

  refreshPage() {
    this.location.go(this.location.path());
    window.location.reload();
  }

  ShowUpdateBooking(id:number)
  {
    this.bookingid = id;
    this.service.SearchBooking(this.bookingid).subscribe(data=>{
      this.oldbooking= data;
    })
    setTimeout(() => {
      this.oldbooking.status = "Paid";
      this.service.UpdateBooking(this.bookingid, this.oldbooking).subscribe(data=>{
        this.refreshPage();
      })
    }, 500); 

    
  }


  DeleteBooking(id:number)
    {
      if (window.confirm('Are you sure you want to delete this booking?'))
      this.service.DeleteBooking(id).subscribe(data=>{
        this.refreshPage();
      });
    }
  

}

