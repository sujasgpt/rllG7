package com.bus.booking.bus;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Bus {
    @Id
    @GeneratedValue
    @Column(name = "bus_id")
    private int id;

    @Column(length = 20)
    private String number;
    
    @Column(length = 20)
    private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Bus(int id, String number, String name) {
		super();
		this.id = id;
		this.number = number;
		this.name = name;
	}

	public Bus() {
		super();
	}
    
}
